<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('includes/db.inc.php');
require_once('includes/delete.inc.php');


if ($_SERVER['REQUEST_METHOD'] === "POST")
{

        if (isset($_POST['delete']) && !empty($_POST['delete']))
        {

            $id = $_POST['id'];
    
            $query = "DELETE FROM participanti WHERE id='$id'";
    
            $result = mysqli_query($conn, $query);

            header("Location: register.php");
        }
    
}

?>

<html>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
        <input type="text" name="delete" value="yes" hidden />
        <input name="id" value="<?php echo $utilizator['id'] ?>" hidden />
        <p>Ești sigur că dorești să ștergi definitiv contul?</p>
        <input type="submit" value="Da, șterge contul!">
        <input type="button" value="Nu, revin la pagina inițială!" onclick="window.location.href = 'login.php';">
</form>
</html>