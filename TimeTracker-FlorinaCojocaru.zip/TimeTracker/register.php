<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('includes/db.inc.php');
require_once('includes/validare.inc.php');
require_once('includes/generateInput.inc.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit']))
{
    if
    (
        validateInput
        ([
            'nume' => ['required' => true, 'min' => 6, 'max' => 30],
            'email' => ['required' => true],
            'departament' => ['required' => true],
            'categorie' => ['required' => true],
            'rol' => ['required' => true],
            'ore'=> ['required' => true],
            'parola' => ['required' => true],
            'repeta_parola' => ['required' => true]
        ])
    )
    {
        // colecatam datele din formular
        $nume = $_POST['nume'];
        $email = $_POST['email'];
        $departament = $_POST['departament'];
        $categorie = $_POST['categorie'];
        $rol = $_POST['rol'];
        $ore = $_POST['ore'];
        $parola = $_POST['parola'];
        $repetaParola = $_POST['repeta_parola'];

        // verificam daca un utilizator cu acelasi e-mail exista deja
        $query = "SELECT * FROM users WHERE email='$email';";

        $response = mysqli_query($conn, $query);
        $rows = mysqli_num_rows($response);
        if ($rows > 0)
        {
            echo 'Exista deja un utilizator cu acelasi email.';
        }else
        {
            // sa verificam parolele sa fie identice
            if ($parola === $repetaParola)
            {
                // sa facem un hash pentru parola si sa il salvam in baza de date 
                $hash = password_hash($parola, PASSWORD_DEFAULT);
                $query = "INSERT INTO users (nume, email, departament, categorie, rol, ore, parola) VALUES ('$nume', '$email', '$departament', '$categorie', '$rol', '$ore', '$hash')";

                mysqli_query($conn, $query);
                header('Location: login.php');
            }else
            {
                $_POST['errors']['parola'] = 'Parolele trebuie sa fie identice.';
            }
        }
    }
}
?>


<html>

<head>
  <style>
    /* CSS for form styling */
    body {
    background-color: #f2f2f2;
  }

  .form-container {
    width: 400px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
    .form-container {
      width: 400px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-field {
      width: 100%;
      padding: 5px;
    }

    .form-submit {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #FFF;
      border: none;
      cursor: pointer;
    }
  </style>
</head>

<body>
<div class="form-container">
<h2>Formular de înregistrare:</h2>

<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
    <div class="form-group">
    <label class="form-label" for="nume">Nume și prenume:</label>
    <?php generateInput('form-field', 'text', 'nume', 'Introduceți numele dumneavoastră!'); ?>
    </div>

    <div class="form-group">
    <label class="form-label" for="email">E-mail:</label>
    <?php generateInput('form-field', 'email', 'email', 'Introduceți adresa de e-mail!'); ?>
    </div>    
        
    <div class="form-group">
        <label class="form-label" for="department">Departament:</label>
        <select class="form-field" name="departament">
        <option value="Comercial">Comercial</option>
            <option value="ResurseUmane">Resurse Umane</option>
            <option value="Financiar">Financiar</option>
            <option value="Administrativ">Administrativ</option>
            <option value="Marketing">Marketing</option>
            <option value="Achizitii">Achiziții</option>
            <option value="Management">Management</option>
        </select>
    </div>
    
    <div class="form-group">
        <label class="form-label" for="categorie">Categorie:</label>
        <select class="form-field" name="categorie">
            <option value="ProjectManager">Project Manager</option>
            <option value="Manager">Manager</option>
            <option value="Programator">Programator</option>
            <option value="Contabil">Contabil</option>
            <option value="Director">Director</option>
            <option value="SpecialistRelatiiCuClientii">Specialist Relații cu Clienții</option>
            <option value="HR">HR</option>
            <option value="Inginer">Inginer</option>
        </select>
    </div>
    
    <div class="form-group">
        <label class="form-label" for="rol">Rol:</label>
        <select class="form-field" name="rol">
            <option value="Utilizator">Utilizator</option>
        </select>
    </div>

    <div class="form-group">
    <label class="form-label" for="parola">Parolă:</label>
    <?php generateInput('form-field', 'password', 'parola', '', 'Introduceți parola!'); ?>
    </div>

    <div class="form-group">
    <label class="form-label" for="repeta_parola">Repetă parola:</label>
    <?php generateInput('form-field', 'password', 'repeta_parola', '', 'Introduceți din nou parola!'); ?>
    </div>

    <input class="form-submit" type='submit' value="Trimite!" name='submit' />
</form>
</div>
</body>
</html>