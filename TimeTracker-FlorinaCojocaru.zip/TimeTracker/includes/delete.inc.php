<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('includes/db.inc.php');

function delete($table, array $dataToDelete, $id)
{
    global $conn;

    foreach ($dataToDelete as $key => $value)
    {
      $updateFields[] = "$key = '$value'";
    }

    $deleteQuery = "DELETE FROM $table WHERE id = '$id'";
    $result = mysqli_query($conn, $deleteQuery);

    if(!$result)
    {
      die('query failed' . mysqli_error($conn));
    }
    return (mysqli_affected_rows($conn) === 1) ? true : false;
}
?>