<?php

require_once('includes/db.inc.php');


// Functie pentru a lua rolul utilizatorului din baza de date
function getUserRole($id) {
    global $conn;
  
    $query = "SELECT rol FROM users WHERE id ='$id'";
  
    $result = mysqli_query($conn, $query);
  
    if(!$result)
    {
      die('query failed' . mysqli_error($conn));
    }
    return (mysqli_affected_rows($conn) === 1) ? true : false;
  }



  // Functie pentru totalul orelor logate
function totalOre($id, $departamentId, $categorieId)
{
  global $conn;

  $query = "SELECT SUM(oreLogate) FROM users WHERE id = '$id' AND departamentId = '$departamentId' AND categorieId = '$categorieId";

  $result = mysqli_prepare($conn, $query);
  mysqli_stmt_bind_param($result, 'iii', $id, $departamentId, $categorieId);
  mysqli_stmt_execute($result);
  mysqli_stmt_bind_result($result, $totalOre);

  if (mysqli_stmt_fetch($result))
  {
    return $totalOre;
  }
  return 0;   // Returnam 0 daca nu sunt ore logate
}
  ?>