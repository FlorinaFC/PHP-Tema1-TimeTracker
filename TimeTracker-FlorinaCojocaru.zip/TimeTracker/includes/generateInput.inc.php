<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function generateInput($class, $type, $name, $value, $placeholder = '', $min = '', $max = '')
{
    $nameValue = isset($_POST[$name]) && !empty($_POST[$name]) ? $_POST[$name] : '';                         // verificam prin $nameValue daca avem o valoare salvata in $_POST
    
    $input = '<input class="' . $class . '" 
                    type="' . $type . '" 
                    name="' . $name . '" 
                    value="' . $value . '"                                                                  
                    placeholder="' . $placeholder . '"
                    min="' . $min . '"
                    max="' . $max . '"
            /> <br>';                                                                                      // alcatuim $input folosind parametrii si valoarea salvata in $_POST

    if (isset($_POST['errors'][$name]) && !empty($_POST['errors'][$name]))                                 // verificam daca exista erori pentru campul respectiv
    {     
        $input .= '<p style="color:red">' . $_POST['errors'][$name] . '</p>';                             // daca exista erori pentru campul respectiv adaugam in inputul nostru eroarea
    }
    echo $input;
}
?>