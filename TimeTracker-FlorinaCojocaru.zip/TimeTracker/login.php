<?php
require_once('includes/db.inc.php');
require_once('includes/generateInput.inc.php');
require_once('includes/validare.inc.php');
require_once('includes/functii.inc.php');

//require_once('utils/logger.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == 'POST' && isset($_POST['submit']))
{
    if(
        // verificam inputul din formular
        validateInput([
            'email' => [
                'required' => true,
            ],
            'parola' => [
              'required' => true,
            ]
        ])
    ){
        $email = $_POST['email'];
        $parola = $_POST['parola'];

          // sa verificam in baza de date daca exista
          $query = "SELECT * FROM users WHERE email='$email';";
          $result = mysqli_query($conn, $query);
          $rows = mysqli_num_rows($result);
          if ($rows > 0)
          {
              //un utilizator cu email si parola care sunt identice cu datele noastre
              $user = mysqli_fetch_assoc($result);

              if(password_verify($parola, $user['parola']))
              {
                  // setam valorea in superglobala de sesiune
                  $_SESSION['email'] = $user['email'];
                  $_SESSION['nume'] = $user['nume'];

                  $id = $user['id'];
                  $rol = $user['rol'];

                  //header("Location: individual.php?id=$id");

                  $query1 = "SELECT rol FROM users WHERE rol ='$rol'";
                  $rol = mysqli_query($conn, $query1);

                  if ($rol === 'administrator')
                  {     
                      header("Location: admin.php?id=$id");
                  }else
                  {
                    header("Location: user.php?id=$id");
                  }
              }
            }else
              {
                echo 'Datele introduse nu sunt corecte.';             
              }
        
      }
}
?>

<html>
<?php require('templates/nav.template.php') ?>

<head>
  <style>
    /* CSS for form styling */
    body {
    background-color: #f2f2f2;
  }

  .form-container {
    width: 400px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
    .form-container {
      width: 400px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-field {
      width: 100%;
      padding: 5px;
    }

    .form-submit {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #FFF;
      border: none;
      cursor: pointer;
    }
  </style>
</head>

<body>
    <div class="form-container">
        <h2>Contul meu:</h2>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">

            <div class="form-group">
            <label class="form-label" for="email">E-mail:</label>
            <?php generateInput('form-field', 'email', 'email', '', 'Introduceți adresa de e-mail!'); ?>
            </div>

            <div class="form-group">
            <label class="form-label" for="parola">Parolă:</label>
            <?php generateInput('form-field', 'password', 'parola', '', 'Introduceți parola!'); ?>
            </div>

            <input class="form-submit" type='submit' value="Intră în cont!" name='submit' />
        </form>
    </div>
</body>
</html>