<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('includes/db.inc.php');
require_once('includes/validare.inc.php');
require_once('includes/generateInput.inc.php');
require_once('includes/rol.inc.php');

session_start();



if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit']))
{
    if (validateInput([
        'nume' => [
            'required' => true,
        ],
        'rol' => [
            'required' => true,
        ]
    ]))
    {
        $id = $_POST['id'];
        $rol = $_POST['rol'];

        // Verificam daca utilizatorul are rol de admin
        $query = "SELECT rol FROM users WHERE id ='$id'";
        $rol = mysqli_query($conn, $query);

        if ($rol === 'administrator')
        {
            $numedepartament = $_POST['numedepartament'];
            $numecategorie = $_POST['numecategorie'];

            // Inserare departament in baza de date
            $insertQueryDepartament = "INSERT INTO departament (numedepartament) VALUES ('$numedepartament')";
            $statementDepartament = mysqli_prepare($conn, $insertQueryDepartament);
            mysqli_stmt_bind_param($statementDepartament, 's', $numedepartament);
            mysqli_stmt_execute($statementDepartament);

            $insertQueryCategorie = "INSERT INTO categorie (numecategorie) VALUES ('$numecategorie')";
            $statementCategorie = mysqli_prepare($conn, $insertQueryCategorie);
            mysqli_stmt_bind_param($statementCategorie, 's', $numecategorie);
            mysqli_stmt_execute($statementCategorie);

            if (mysqli_stmt_affected_rows($statementDepartament) > 0)
            {
                echo "Noul departament '$numedepartament' a fost adăugat cu succes.";
            }
            elseif(mysqli_stmt_affected_rows($statementCategorie) > 0)
            {
                echo "Noua categorie '$numecategorie' a fost adăugată cu succes.";
            }
            else
            {
                echo "Câmpul nu a fost adăugat.";
            }
        }
    }
?>

<!-- Formularul HTML pentru a adauga un nou departament sau categorie. -->
<form method="POST" action="">
  <label for="departament">Nume departament:</label>
  <input type="text" name="departament" id="departament" required>
  <button type="submit">Adaugă departament</button>
</form>

<form method="POST" action="">
  <label for="categorie">Nume categorie:</label>
  <input type="text" name="categorie" id="categorie" required>
  <button type="submit">Adaugă categorie</button>
</form>

<?php
} else {
//Mesaj de eroare pentru utilizatorii care nu sunt administratori
  echo "Nu aveți suficiente drepturi pentru a adăuga un nou departament sau o nouă categorie.";
}
?>