<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('includes/generateInput.inc.php');

?>


<html>
<?php require('templates/nav.template.php'); ?>

<head>
  <style>
    /* CSS for form styling */
    body {
    background-color: #f2f2f2;
  }

  .form-container {
    width: 400px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
    .form-container {
      width: 400px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-field {
      width: 100%;
      padding: 5px;
    }

    .form-submit {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #FFF;
      border: none;
      cursor: pointer;
    }
  </style>
</head>

<body>
<!-- HTML form to log hours -->
<div class="form-container">
    <h2>Adăugare ore:</h2>  
    
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>">
    <input name="id" value="<?php echo $utilizator['id'] ?>" hidden />

    <div class="form-group">
        <label class="form-label" for="department">Departament:</label>
        <select class="form-field" name="departament", <?php $utilizator['departament']?>>
            <option value="Comercial">Comercial</option>
            <option value="ResurseUmane">Resurse Umane</option>
            <option value="Financiar">Financiar</option>
            <option value="Administrativ">Administrativ</option>
            <option value="Marketing">Marketing</option>
            <option value="Achizitii">Achiziții</option>
            <option value="Management">Management</option>
        </select>
    </div>
    
    <div class="form-group">
        <label class="form-label" for="categorie">Categorie:</label>
        <select class="form-field" name="categorie" <?php $utilizator['categorie']?>>
            <option value="ProjectManager">Project Manager</option>
            <option value="Manager">Manager</option>
            <option value="Programator">Programator</option>
            <option value="Contabil">Contabil</option>
            <option value="Director">Director</option>
            <option value="SpecialistRelatiiCuClientii">Specialist Relații cu Clienții</option>
            <option value="HR">HR</option>
            <option value="Inginer">Inginer</option>
        </select>
    </div>


    <div class="form-group">
    <label class="form-label" for="ore">Logged Hours:</label>
    <?php generateInput('form-field', 'number', 'ore', 'ore', 0, 8); ?>
    </div>

    <input class="form-submit" type='submit' value="Adaugă ore!" />
</form>
</div>
</body>
</html>