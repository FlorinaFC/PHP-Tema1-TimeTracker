<?php
?>

<!DOCTYPE html>
<html>
<head>
  <style>
    /* CSS for styling */
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 20px;
    }

    .welcome-message {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .nav-link {
      display: inline-block;
      margin-right: 10px;
      text-decoration: none;
      color: #000000;
      font-weight: bold;
      font-size: 18px;

      padding: 5px 10px;
      border-radius: 5px;
      background-color: #f0e0e0;
    }

    .nav-link:hover {
      background-color: #ccc;
    }
  </style>
</head>
<body>


  <?php
    if (isset($_SESSION['email']) && !empty($_SESSION['email'])
        && isset($_SESSION['nume']) && !empty($_SESSION['nume']))
    {
      ?>
      <!-- <a class="nav-link" href="index.php">Acasă</a> -->
      <a class="nav-link" href="login.php?">Contul meu</a>
      <a class="nav-link" href="departamente.php">Departamente</a>
      <a class="nav-link" href="loggedHours.php">Logged Hours</a>
      <a class="nav-link" href="includes/logout.inc.php">Ieșire</a>
      <a class="nav-link" href="deleteaccount.php">Șterge contul</a>
      <br>
      <br>
      <div class="welcome-message">
        Bine ai venit, <?php echo $_SESSION['nume'] . '!' ?>
      </div>
      <?php
        }else
    {
      ?>
      <a class="nav-link" href="register.php">Înregistrare</a>
      <?php
    }
  ?>
</body>
</html>
