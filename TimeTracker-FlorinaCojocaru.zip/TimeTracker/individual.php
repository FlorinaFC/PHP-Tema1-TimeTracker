<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('includes/db.inc.php');
require_once('includes/validare.inc.php');
require_once('includes/generateInput.inc.php');
require_once('includes/update.inc.php');

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'GET') //identificam userul
{
    if (isset($_GET['id']) && !empty($_GET['id']))
    {
        $id = $_GET['id'];         // cules date din baza de date pentru userul respectiv
        $query = "SELECT * FROM users WHERE id='$id'";

        $result = mysqli_query($conn, $query);
        $utilizator = mysqli_fetch_assoc($result);
    }else
    {
        die('Utilizator inexistent!');
    }
}

if ($_SERVER['REQUEST_METHOD'] === "POST")
{
    if (isset($_POST['email']) && !empty($_POST['email']))
    {
        $id = $_POST['id'];
        $query = "SELECT * FROM users WHERE id='$id'";

        $result = mysqli_query($conn, $query);
        $utilizator = mysqli_fetch_assoc($result);
    }else
    {
        if (
            validateInput([
                'nume' => [
                    'required' => true,
                    'min' => 3,
                    'max' => 30
                ],
                'email' => [
                    'required' => true,
                ],
                'departament' => [
                    'required' => true,
                ],
                'categorie' => [
                    'required' => true,
                ],
                'parola' => [
                    'required' => true,
                ],
                'ore' => [
                    'required' => true,
                ]
            ])
        ){
            $id = $_POST['id'];
            $nume = $_POST['nume'];
            $email = $_POST['email'];
            $departament = $_POST['departament'];
            $categorie = $_POST['categorie'];
            $parola = $_POST['parola'];
            $ore = $_POST['ore'];

            update(
            'users',
            ['nume'=>$nume,
            'email'=>$email,
            'departament'=>$departament,
            'categorie'=>$categorie,
            'parola'=>$parola,
            'ore'=>$ore
            ],
            $id);

            header("Location: individual.php?id=$id");
        } else
        {
            echo '<p style="color:red">Nu ati introdus toate datele corect!</p>';
            echo '<br>';
        }
    }
}
?>


<html>
<?php require('templates/nav.template.php'); ?>

<head>
  <style>
    /* CSS for form styling */
    body {
    background-color: #f2f2f2;
  }

  .form-container {
    width: 400px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
    .form-container {
      width: 400px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-field {
      width: 100%;
      padding: 5px;
    }

    .form-submit {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #FFF;
      border: none;
      cursor: pointer;
    }
  </style>
</head>

<body>
    <div class="form-container">
    <h2>Actualizare date:</h2>  
    
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>">
    <input name="id" value="<?php echo $utilizator['id'] ?>" hidden />

    <div class="form-group">
    <label class="form-label" for="nume">Nume și prenume:</label>
    <?php generateInput('form-field', 'text', 'nume', $utilizator['nume']); ?>
    </div>

    <div class="form-group">
    <label class="form-label" for="email">E-mail:</label>
    <?php generateInput('form-field', 'email', 'email', $utilizator['email']); ?>
    </div>    
    
    <div class="form-group">
        <label class="form-label" for="department">Departament:</label>
        <select class="form-field" name="departament", <?php $utilizator['departament']?>>
            <option value="Comercial">Comercial</option>
            <option value="ResurseUmane">Resurse Umane</option>
            <option value="Financiar">Financiar</option>
            <option value="Administrativ">Administrativ</option>
            <option value="Marketing">Marketing</option>
            <option value="Achizitii">Achiziții</option>
            <option value="Management">Management</option>
        </select>
    </div>
    
    <div class="form-group">
        <label class="form-label" for="categorie">Categorie:</label>
        <select class="form-field" name="categorie" <?php $utilizator['categorie']?>>
            <option value="ProjectManager">Project Manager</option>
            <option value="Manager">Manager</option>
            <option value="Programator">Programator</option>
            <option value="Contabil">Contabil</option>
            <option value="Director">Director</option>
            <option value="SpecialistRelatiiCuClientii">Specialist Relații cu Clienții</option>
            <option value="HR">HR</option>
            <option value="Inginer">Inginer</option>
        </select>
    </div>
    
    <div class="form-group">
    <label class="form-label" for="ore">Ore:</label>
    <?php generateInput('form-field', 'number', 'ore', $utilizator['ore']); ?>
    </div>
    
    <div class="form-group">
    <label class="form-label" for="parola">Parolă:</label>
    <?php generateInput('form-field', 'password', 'parola', ''); ?>
    </div>

    <div class="form-group">
    <label class="form-label" for="repeta_parola">Repetă parola:</label>
    <?php generateInput('form-field', 'password', 'repeta_parola', ''); ?>
    </div>

    <input class="form-submit" type='submit' value="Actualizează datele!" />
    </form>



</div>
</body>
</html>