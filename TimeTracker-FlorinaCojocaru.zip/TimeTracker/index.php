<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

require_once('includes/db.inc.php');
require_once('includes/validare.inc.php');
require_once('includes/generateInput.inc.php');

if (!isset($_SESSION['email']) || empty($_SESSION['email'])) {
    header('Location: register.php'); // regula de aplicat in toate fisierele protejate de autentificare
}

$selectQuery = "SELECT * FROM users";
$array = mysqli_query($conn, $selectQuery);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        validateInput([
            'nume' => [
                'required' => true,
                'min' => 3,
                'max' => 30
            ],
            'email' => [
                'required' => true,
            ],
            'departament' => [
                'required' => true,
            ],
            'categorie' => [
                'required' => true,
            ],
            'rol' => [
                'required' => true,
            ],
            'ore' => [
                'required' => true,
            ],
            'parola' => [
                'required' => true,
            ],
        ])
    ) {

        $nume = $_POST['nume'];
        $email = $_POST['email'];
        $departament = $_POST['departament'];
        $categorie = $_POST['categorie'];
        $rol = $_POST['rol'];
        $ore = $_POST['ore'];
        $parola = $_POST['parola'];


        $query = "INSERT INTO users (nume, email, departament, categorie, rol, ore, parola) VALUES ('$nume', '$email', '$departament', '$categorie', '$rol', '$ore', '$parola')";

        mysqli_query($conn, $query);

        echo 'Datele au fost inregistrate';
        echo "<br>";
        header('Location: /index.php');

    } else {
        echo '<p style="color:red">Nu ati introdus datele corect!</p>';
        echo '<br>';
    }

}

// redirectionare spre pagina 
?>



<html>
<?php require('templates/nav.template.php'); ?>
<!-- <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
    <br>
    <label>Nume si prenume:</label>
    <br>
    <?php generateInput('text', 'nume', 'Introduceti numele!'); ?>
    <br>
    <label>E-mail:</label>
    <br>
    <?php generateInput('email', 'email', 'Introduceti adresa de email!'); ?>
    <br>
    <label>Departament:</label>
    <br>
    <br>
    <select name="departament" id="departament">
            <option value="Comercial">Comercial</option>
            <option value="ResurseUmane">Resurse Umane</option>
            <option value="Financiar">Financiar</option>
            <option value="Administrativ">Administrativ</option>
            <option value="Marketing">Marketing</option>
            <option value="Achizitii">Achizitii</option>
            <option value="Management">Management</option>
    </select>
    <br>
    <br>
    <label>Categorie:</label>
    <br>
    <br>
    <select name="categorie" id="categorie">
            <option value="ProjectManager">Project Manager</option>
            <option value="Manager">Manager</option>
            <option value="Programator">Programator</option>
            <option value="Contabil">Contabil</option>
            <option value="Director">Director</option>
            <option value="SpecialistRelatiiCuClientii">Specialist Relatii cu Clientii</option>
            <option value="HR">HR</option>
            <option value="Inginer">Inginer</option>
    </select>
    <br>
    <br>
    <label>Rol:</label>
    <br>
    <br>
    <select name="rol" id="rol">
            <option value="Administrator">Administrator</option>
            <option value="Utilizator">Utilizator</option>
    </select>
    <br>   
    <br>
    <label>Ore:</label>
    <br>
    <?php generateInput('number', 'ore', 'Numarul de ore'); ?>
    <br>
    <label>Parola:</label>
    <br>
    <?php generateInput('password', 'parola', 'Introduceti parola!'); ?>
    <br>
    <label>Repeta parola:</label>
    <br>
    <?php generateInput('password', 'repeta_parola', 'Repetati parola!'); ?>
    <br>
    <input type='submit' value="Trimite!" name='submit' />
</form> -->

</html>